package com.example.dylonmclay.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends    AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button newCharButton = (Button) findViewById(R.id.newCharButton);
        newCharButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent newCharIntent = new Intent(MainActivity.this, NewCharActivity.class);
                newCharIntent.putExtra("editChar",false);
                startActivity(newCharIntent);
            }
        });

        Button charListButton = (Button) findViewById(R.id.viewCharButton);
        charListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent charListIntent = new Intent(MainActivity.this, CharListActivity.class);
                charListIntent.putExtra("newChar", false);
                startActivity(charListIntent);
            }
        });
    }
}
