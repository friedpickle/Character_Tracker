package com.example.dylonmclay.project;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


/**
 * Created by Dylon McLay on 2017-10-27.
 */

public class CharProfileActivity extends AppCompatActivity {
    public boolean newChar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.i("PROFILE", "CREATED ");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.character_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.charProfileToolBar);
        setSupportActionBar(toolbar);

        TextView charName = (TextView) findViewById(R.id.charName);
        TextView charLvl = (TextView) findViewById(R.id.charLvl);
        TextView charRace = (TextView) findViewById(R.id.charRace);
        TextView charClass = (TextView) findViewById(R.id.charClass);
        TextView strT = (TextView) findViewById(R.id.str);
        TextView dexT = (TextView) findViewById(R.id.dex);
        TextView conT = (TextView) findViewById(R.id.con);
        TextView intT = (TextView) findViewById(R.id.intel);
        TextView wisT = (TextView) findViewById(R.id.wis);
        TextView chaT = (TextView) findViewById(R.id.cha);
        checkNewChar();

        final Character c = (Character) getIntent().getExtras().get("Char");


        charName.setText(charName.getText() + " " + c.getCharName());
        charLvl.setText(charLvl.getText() + " " + c.getCharLevel());
        charRace.setText(charRace.getText() + " " + c.getCharRace());
        charClass.setText(charClass.getText() + " " + c.getCharClass());
        strT.setText(strT.getText() + "  " + c.getStr());
        dexT.setText(dexT.getText() + "  " + c.getDex());
        conT.setText(conT.getText() + "  " + c.getCon());
        intT.setText(intT.getText() + "  " + c.getIntel());
        wisT.setText(wisT.getText() + "  " + c.getWis());
        chaT.setText(chaT.getText() + "  " + c.getCha());


        Button go = (Button) findViewById(R.id.toList);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent charListIntent = new Intent(CharProfileActivity.this, CharListActivity.class);
                Character c2 = new Character(c.getCharName(), c.getCharLevel(), c.getCharRace()
                        , c.getCharClass(), c.getStr(), c.getDex(), c.getCon(), c.getIntel(), c.getWis(), c.getCha());
                charListIntent.putExtra("char", c2);

                if (newChar)
                    charListIntent.putExtra("newChar", true);

                startActivity(charListIntent);
            }

        });
    }

    public void checkNewChar() {
        newChar = getIntent().getExtras().getBoolean("newChar");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.char_profile_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_menu:
                Intent homeIntent = new Intent(CharProfileActivity.this, MainActivity.class);
                startActivity(homeIntent);
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
    }
}
