package com.example.dylonmclay.project;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import java.io.Serializable;

/**
 * Created by Dylon McLay on 2017-10-27.
 */
@Entity
public class Character extends Object implements Serializable{
    @PrimaryKey
    public int id;
    private String charName, charLevel, charRace, charClass, str, dex, con, intel, wis, cha;
    public Character(){
        id=0;
        charName="";
        charLevel="";
        charRace="";
        charClass="";
        str="";
        dex="";
        con="";
        intel="";
        wis="";
        cha="";
    }

    public Character(String charName, String charLevel, String charRace, String charClass,String str,String dex,String con,String intel,String wis,String cha){

        this.charName = charName;
        this.charLevel = charLevel;
        this.charRace = charRace;
        this.charClass = charClass;
        this.str = str;
        this.dex = dex;
        this.con = con;
        this.intel = intel;
        this.wis = wis;
        this.cha = cha;
    }

    public String getCharName() {
        return charName;
    }

    public void setCharName(String charName) {
        this.charName = charName;
    }

    public String getCharLevel() {
        return charLevel;
    }

    public void setCharLevel(String charLevel) {
        this.charLevel = charLevel;
    }

    public String getCharRace() {
        return charRace;
    }

    public void setCharRace(String charRace) {
        this.charRace = charRace;
    }

    public String getCharClass() {
        return charClass;
    }

    public void setCharClass(String charClass) {
        this.charClass = charClass;
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    public String getDex() {
        return dex;
    }

    public void setDex(String dex) {
        this.dex = dex;
    }

    public String getCon() {
        return con;
    }

    public void setCon(String con) {
        this.con = con;
    }

    public String getIntel() {
        return intel;
    }

    public void setIntel(String intel) {
        this.intel = intel;
    }

    public String getWis() {
        return wis;
    }

    public void setWis(String wis) {
        this.wis = wis;
    }

    public String getCha() {
        return cha;
    }

    public void setCha(String cha) {
        this.cha = cha;
    }
}
