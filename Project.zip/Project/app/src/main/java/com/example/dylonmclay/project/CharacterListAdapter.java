package com.example.dylonmclay.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import static com.example.dylonmclay.project.R.array.characters;

/**
 * Created by Dylon McLay on 2017-11-29.
 */

public class CharacterListAdapter extends ArrayAdapter<Character> {
    private Character c;
    public CharacterListAdapter(Context context, ArrayList<Character> characters) {
        super(context, 0, characters);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Character c = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.char_list_layout, parent, false);
        }
        //item title
        TextView name = (TextView) convertView.findViewById(R.id.name);
        //subtitle
        TextView addInfo = (TextView) convertView.findViewById(R.id.addInfo);
        System.out.println(characters);
        name.setText(c.getCharName());
        addInfo.setText("lvl" + c.getCharLevel() + " " + c.getCharRace() + " " + c.getCharClass());
        // Return the completed view to render on screen
        return convertView;
    }
}
