package com.example.dylonmclay.project;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.dylonmclay.project.Character;
/**
 * Created by Dylon McLay on 2017-10-27.
 */

public class NewCharActivity extends AppCompatActivity {
    public String charName, charLvl, charRace, charClass, str, dex, con, intel, wis, cha;
    public Character c;
    public boolean checkEdit = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_character);
        //toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.newCharToolbar);
        setSupportActionBar(toolbar);



        Log.i("NCA", "Created ");

        final EditText charNameText = (EditText) findViewById(R.id.charName);
        final EditText charLvlText = (EditText) findViewById(R.id.charLevel);
        final EditText charRaceText = (EditText) findViewById(R.id.charRace);
        final EditText charClassText = (EditText) findViewById(R.id.charClass);
        final EditText strT = (EditText) findViewById(R.id.str);
        final EditText dexT = (EditText) findViewById(R.id.dex);
        final EditText conT = (EditText) findViewById(R.id.con);
        final EditText intT = (EditText) findViewById(R.id.intel);
        final EditText wisT = (EditText) findViewById(R.id.wis);
        final EditText chaT = (EditText) findViewById(R.id.cha);

        checkIfEdit();
        //check if character is to be edited, if so, text fields field out for editting.
        if(checkEdit) {
            Character c2 = (Character)getIntent().getExtras().get("Char");
            charNameText.setText(c2.getCharName());
            charLvlText.setText(c2.getCharLevel());
            charRaceText.setText(c2.getCharRace());
            charClassText.setText(c2.getCharClass());
            strT.setText(c2.getStr());
            dexT.setText(c2.getDex());
            conT.setText(c2.getCon());
            intT.setText(c2.getIntel());
            wisT.setText(c2.getWis());
            chaT.setText(c2.getCha());
        }

        Button saveButton = (Button) findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Log.i("attributes sotred", "onClick: ");
                charName = charNameText.getText().toString();
                charLvl = charLvlText.getText().toString();
                charRace = charRaceText.getText().toString();
                charClass = charClassText.getText().toString();
                str = strT.getText().toString();
                dex = dexT.getText().toString();
                con = conT.getText().toString();
                intel = intT.getText().toString();
                wis = wisT.getText().toString();
                cha = chaT.getText().toString();
                c = new Character(charName,charLvl,charRace,charClass,str,dex,con,intel,wis,cha);

                Log.i("FINISH", "STATS STORED ");

                Context context = getApplicationContext();
                int duration = Toast.LENGTH_SHORT;
                CharSequence text = "saved Character.";

                Toast bread = Toast.makeText(context,text,duration);
                bread.show();
                //go to char profile
                Intent charProfileIntent = new Intent(NewCharActivity.this, CharProfileActivity.class);

                charProfileIntent.putExtra("Char",c);
                charProfileIntent.putExtra("newChar",true);

                startActivity(charProfileIntent);
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.new_char_menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_menu:
                Intent homeIntent = new Intent(NewCharActivity.this, MainActivity.class);
                startActivity(homeIntent);
                return true;


            default:
                return super.onOptionsItemSelected(item);

        }
    }

    public void checkIfEdit(){
        checkEdit = getIntent().getExtras().getBoolean("editChar");
    }
}
