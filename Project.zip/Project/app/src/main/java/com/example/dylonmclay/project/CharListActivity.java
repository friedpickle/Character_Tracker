package com.example.dylonmclay.project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Dylon McLay on 2017-11-02.
 */

public class CharListActivity extends AppCompatActivity {
    // public final String SHARED_PREF = "sharedPref";
    //  public final String CHARLIST = "charList";
    private CharacterListAdapter adapter;
    private boolean newChar;
    private ArrayList<Character> characters;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.character_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.charListToolBar);
        setSupportActionBar(toolbar);
        toolbar.showOverflowMenu();
        Log.i("LISTVIEW MADE", "DONE");

        newChar = false;
        checkNewChar();

        ListView lv = (ListView) findViewById(R.id.charList);

        characters = new ArrayList<Character>();
        characters = load();
        Log.i("LIST", "LOADED");
        System.out.println(newChar + "***");
        Character c;
        adapter = new CharacterListAdapter(this, characters);
        if (newChar) {
            c = (Character) getIntent().getExtras().get("char");
            System.out.println(c.getCharName());
            adapter.add(c);
        }

        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent charProfIntent = new Intent(CharListActivity.this, CharProfileActivity.class);
                Character c = (Character) adapterView.getAdapter().getItem(i);
                save(characters);

                charProfIntent.putExtra("Char", c);
                charProfIntent.putExtra("newChar", false);
                System.out.println(c.getCharName());
                startActivity(charProfIntent);
            }
        });

        registerForContextMenu(lv);

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                return false;
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }


    public void checkNewChar(){
        newChar = getIntent().getExtras().getBoolean("newChar");
    }

    //top bar items
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.char_list_menu,menu);
        MenuItem item = menu.findItem(R.id.action_menu);
       // spinner.setAdapter(adapter);
        return true;
    }

    //pop up items
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()) {
            case R.id.menu_edit:
                edit(characters.remove(info.position));
                return true;
            case R.id.menu_delete:
                delete(characters.get(info.position));
                save(characters);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
    //Remove a character from the list, then save
    public void delete(Character c){
        adapter.remove(c);
    }

    //Remove character from a list, then saves, need to go through newChar process, updating info, then adds the updated character to the list.
    public void edit(Character c){
        Intent editCharIntent = new Intent(CharListActivity.this, NewCharActivity.class);
        editCharIntent.putExtra("editChar",true);
        editCharIntent.putExtra("Char", c);
        save(characters);
        startActivity(editCharIntent);
    }


//Top bar menu
        @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                Intent newCharIntent = new Intent(CharListActivity.this, NewCharActivity.class);
                newCharIntent.putExtra("newChar",true);
                save(characters);
                startActivity(newCharIntent);
                return true;

            case R.id.action_menu:
                save(characters);
                Intent homeIntent = new Intent(CharListActivity.this, MainActivity.class);
                startActivity(homeIntent);
                return true;


            default:
                return super.onOptionsItemSelected(item);

        }
    }
    public void save(ArrayList<Character> list){
        String mySavedList= new Gson().toJson(list);
        PreferenceManager.getDefaultSharedPreferences(this).edit().putString("My_SAVED_LIST", mySavedList).commit();
    }
    public ArrayList<Character>load(){
        ArrayList<Character> myList = new Gson().fromJson(PreferenceManager.getDefaultSharedPreferences(this).getString("My_SAVED_LIST", ""), new TypeToken<ArrayList<Character>>() {
        }.getType());
        return myList;
    }
}
